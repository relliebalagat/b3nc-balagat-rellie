<?php

session_start();

// display message on various item

$_SESSION['message'] = array(
	


);