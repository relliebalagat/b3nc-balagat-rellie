<form class="search-area">
	<div class="form-group">
		<select class="form-control">
			<option>By Keyword</option>
			<option>By Title</option>
			<option>By Author</option>
			<option>By ISBN</option>
		</select>
		<input type="text" class="form-control" placeholder="Search for books by keyword | title | author ">
		<button type="submit" class="btn btn-default">Submit</button>	
		<button type="submit" class="btn btn-default">Advanced Search</button>	
	</div>
</form>