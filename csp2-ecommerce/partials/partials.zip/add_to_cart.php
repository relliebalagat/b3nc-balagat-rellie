<?php

session_start();

$id = $_GET['id'];

echo $id;